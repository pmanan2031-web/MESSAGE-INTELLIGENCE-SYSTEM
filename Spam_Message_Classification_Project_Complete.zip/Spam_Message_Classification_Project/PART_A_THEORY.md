# Part A — Probability & Conceptual Foundation

1. Conditional Probability
2. Bayes' Theorem
3. Naive Bayes assumptions
4. KNN and SVM working principles
5. Distance-based vs probabilistic vs margin-based classifiers

The visual assets in the main README connect these concepts to the spam-message classification project.
